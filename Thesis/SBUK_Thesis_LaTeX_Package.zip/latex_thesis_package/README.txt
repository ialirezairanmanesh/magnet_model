پایان‌نامه دانشگاه شهید باهنر کرمان (SBUK Thesis Template)

نحوه کامپایل:
1. مطمئن شوید XeLaTeX و BibTeX روی سیستم شما نصب هستند
2. فایل compile.sh را اجرا کنید: ./compile.sh
   یا به صورت دستی:
   xelatex SBUKThesis-main.tex
   bibtex SBUKThesis-main
   xelatex SBUKThesis-main.tex
   xelatex SBUKThesis-main.tex

فایل‌های اصلی:
- SBUKThesis-main.tex: فایل اصلی پایان‌نامه
- SBUKThesis-main_pandoc.tex: نسخه سازگار با pandoc
- SBUKThesis-commands.tex: تنظیمات و دستورات LaTeX
- SBUKThesis-bibliography.bib: فایل مراجع
- فصل‌ها: SBUKThesis-chapter1.tex تا SBUKThesis-chapter6.tex
- images/: پوشه تصاویر مورد استفاده در پایان‌نامه

برای کامپایل نیاز به بسته‌های زیر دارید:
- XeLaTeX
- biblatex با backend=biber
- بسته‌های فارسی: xepersian
- بسته‌های دیگر: threeparttable, etc.
